import { handleSubmit } from '../js/formHandler'

describe("testing form handler ", () => {

    test('Form Handler defined', () => {
        expect(handleSubmit).toBeDefined()
    })

})